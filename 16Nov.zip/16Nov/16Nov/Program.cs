﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _16Nov
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Q1distinct.show();
            //Q2DayOfMonth.show();
            Q3PriviusDate.Show();
        }
    }
}
