﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _16Nov
{
    internal class Q1distinct
    {
        internal static void show()
        {
            List<String> list = new List<String>();
            Console.WriteLine("Enter the product count");
            int cnt=int.Parse(Console.ReadLine());
            for (int i = 0; i < cnt; i++)
            {
                Console.WriteLine("enter the Product Name");
               list.Add(Console.ReadLine());

            }
            var Query=(from obj in list
                     orderby obj 
                      select obj).Distinct();

            Console.WriteLine("The output is..");
            foreach (var item in Query)
            {
                Console.WriteLine(item);
            }
            Console.ReadLine();
        }
    }
}
