﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _16Nov
{
    internal class Q2DayOfMonth
    {
        internal static void show()

        {
            
            
             Console.Write("Enter the Month No. : ");
             int  mn = Convert.ToInt32(Console.ReadLine());

             Console.Write("Enter the Year : ");
             int  yr = Convert.ToInt32(Console.ReadLine());

             DateTimeFormatInfo dinfo = new DateTimeFormatInfo();
             string mnum = dinfo.GetMonthName(mn);
             int nodays = DateTime.DaysInMonth(yr, mn);
             Console.WriteLine(" The Number of days in the month {0} is : {1} \n", mnum, nodays);
           
           
        }
    }
}
